﻿using Assignment2.Data;
using Assignment2.Data.IReposetory;
using Assignment2.Models;
using Assignment2.Models.VM;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.DependencyInjection;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore.Update.Internal;

namespace Assignment2.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly NeoSoftVishalBoneContext _context;
        private IUnitofwork _unitofwork;
        private IWebHostEnvironment _webHostEnvironment;
        private readonly IHttpClientFactory _httpClientFactory;


        public EmployeeController(IUnitofwork unitofwork, IWebHostEnvironment webHostEnvironment, NeoSoftVishalBoneContext context, IHttpClientFactory httpClientFactory)
        {
            _unitofwork = unitofwork;
            _webHostEnvironment = webHostEnvironment;
            _context = context;
            _httpClientFactory = httpClientFactory;
        }
        #region APICALL
        public IActionResult Alldetails()
        {
            var empmasters = _unitofwork.employei.GetAll(includeproperties: "Country", stateproperties: "State", cityproperties: "City");
            //var activeEmpmasters = empmasters.Where(emp => emp.isActive == true);
            var activeEmpmasters = empmasters.Where(emp => emp.DeletedDate == null);
            return Json(new { data = activeEmpmasters });
        }
        #endregion
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> createupdate(int? id)
        {
            
            if (id == null || id == 0)
            {
                EmployeeVM vm = new EmployeeVM()
                {
                    employeemaster = new(),
                    Countries = _unitofwork.country.GetAll().Select(X =>
                    new SelectListItem()
                    {
                        Text = X.CountryName,
                        Value = X.CountryId.ToString()
                    })

                };
                return View(vm);
            }
            else 
            {
                EmployeeMaster emp = _unitofwork.employei.GetT(x=>x.RowId == id);
                EmployeeVM vm = new EmployeeVM()
                {
                    employeemaster = new(),
                    Countries = _unitofwork.country.GetAll().Select(X =>
                    new SelectListItem()
                    {
                        Text = X.CountryName,
                        Value = X.CountryId.ToString()
                    }),
                    states = _unitofwork.state.GetAll(u=>u.CountryId == emp.CountryId).Select(X =>
                    new SelectListItem()
                    {
                        Text = X.StateName,
                        Value = X.StateId.ToString()
                    }),
                    Cities = _unitofwork.city.GetAll(u=> u.StateId == emp.StateId).Select(X =>
                    new SelectListItem()
                    {
                        Text = X.CityName,
                        Value = X.CityId.ToString()
                    })

                };
                ViewBag.SelectedGender = vm.employeemaster.Gender;
                vm.employeemaster = _unitofwork.employei.GetT(X => X.RowId == id);
                if (vm.employeemaster == null)
                {
                    return NotFound();
                }
                else
                {
                    return View(vm);
                }
            }
            
        }

        [HttpPost]
        public IActionResult createupdate(EmployeeVM evm, IFormFile? file, IFormCollection? frm)
        {
            if (ModelState.IsValid)
            {
                string filename = string.Empty;
                if (file != null)
                {
                    string uplodDir = Path.Combine(_webHostEnvironment.WebRootPath, "Images");
                    filename = Guid.NewGuid().ToString() + "-" + file.FileName;
                    string filepath = Path.Combine(uplodDir, filename);
                    if(evm.employeemaster.ProfileImage != null)
                    {
                        var oldimagepath = Path.Combine(_webHostEnvironment.WebRootPath, "Images", evm.employeemaster.ProfileImage.TrimStart());
                        if (System.IO.File.Exists(oldimagepath))
                        {
                            System.IO.File.Delete(oldimagepath);
                        }
                    }
                    using (var filestream = new FileStream(filepath, FileMode.Create))
                    {
                        file.CopyTo(filestream);
                    }
                    evm.employeemaster.ProfileImage = filename;
                    evm.employeemaster.ProfileImage = filename;
                }
                if (evm.employeemaster.RowId == 0)
                {
                    string gender = frm["Gender"].ToString();
                    string Active = frm["IsActive"].ToString();
                    if(Active == null)
                    {
                        evm.employeemaster.IsActive = false;
                    }
                    else
                    {
                        evm.employeemaster.IsActive = true;
                    }
                    evm.employeemaster.PassPortNumber = evm.employeemaster.PassPortNumber.ToUpper();
                    evm.employeemaster.PanNumber = evm.employeemaster.PanNumber.ToUpper();
                    evm.employeemaster.CreatedDate = DateTime.Now;
                    _unitofwork.employei.Add(evm.employeemaster);
                    TempData["Success"] = "Data added successfully";
                }
                else
                {
                    string Active = frm["IsActive"].ToString();
                    if (Active == null || Active == "")
                    {
                        evm.employeemaster.IsActive = false;
                    }
                    else
                    {
                        evm.employeemaster.IsActive = true;
                    }
                    evm.employeemaster.UpdatedDate = DateTime.Now;
                    _unitofwork.employei.update(evm.employeemaster);
                    TempData["Success"] = "Data updated successfully";
                }
                _unitofwork.save();
                return RedirectToAction("Index");
            }
            return View(evm);
        }

        #region DELETEAPICALL
        [HttpDelete]
        public IActionResult delete(int? id)
        {
            var emprecord = _unitofwork.employei.GetT(x => x.RowId == id);
            if (emprecord == null)
            {
                return Json(new { success = false, message = "Error in fetching data" });
            }
            else
            {
                //var oldimagepath = Path.Combine(_webHostEnvironment.WebRootPath, "Images", emprecord.ProfileImage.TrimStart());
                //if (System.IO.File.Exists(oldimagepath))
                //{
                //    System.IO.File.Delete(oldimagepath);
                //}
                emprecord.IsActive = false;
                emprecord.IsDeleted = true;
                emprecord.DeletedDate = DateTime.Now;
                _unitofwork.employei.update(emprecord);
                //_unitofwork.employei.Delete(emprecord);
                _unitofwork.save();
                return Json(new { success = true, message = "Deleted Successfully" });
            }
        }
        #endregion

        [HttpPost]
        public IActionResult checkuniqueemail(string email, string? id)
        {
            var rowid = int.Parse(id);
            EmployeeMaster emailid = _unitofwork.employei.GetT(X => X.EmailAddress == email);
            if (emailid != null && emailid.RowId == rowid)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = emailid != null ? false : true });
            }
           
        }


        [HttpPost]
        public IActionResult checkmobilenumber(string num, string? id)
        {
            var rowid = int.Parse(id);
            EmployeeMaster Mbno = _unitofwork.employei.GetT(X => X.MobileNumber == num);
            if (Mbno != null && Mbno.RowId == rowid)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = Mbno != null ? false : true });
            }
        }

        [HttpPost]
        public IActionResult checkuniquepan(string pan, string? id)
        {
            int rowid = int.Parse(id);
            EmployeeMaster PANnum = _unitofwork.employei.GetT(X => X.PanNumber == pan);
            if (PANnum != null && PANnum.RowId == rowid)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = PANnum != null ? false : true });
            }
        }

        [HttpPost]
        public IActionResult checkuniquepass(string pass, string? id)
        {
            int rowid = int.Parse(id);
            EmployeeMaster Passno = _unitofwork.employei.GetT(X => X.PassPortNumber == pass);
            if (Passno != null && Passno.RowId == rowid)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = Passno != null ? false : true });
            }
        }

        [HttpPost]
        public IActionResult getstate(int? cid)
        {
            return Json(_context.States.Where(x=>x.CountryId ==  cid).ToList());
        }
        [HttpPost]
        public IActionResult getcity(int? sId)
        {
            return Json(_context.Cities.Where(x => x.StateId == sId).ToList());
        }
    }
}
