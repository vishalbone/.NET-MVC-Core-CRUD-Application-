﻿using Assignment2.Data.IReposetory;
using Assignment2.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace Assignment2.Data.Reposetory
{
    public class reposetory<T> : Ireposetory<T> where T : class
    {
        private readonly NeoSoftVishalBoneContext _context;
        private DbSet<T> _dbSet;

        public reposetory(NeoSoftVishalBoneContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        public void Add(T item)
        {
            _dbSet.Add(item);
        }

        public void Delete(T item)
        {
            _dbSet.Remove(item);
        }

        public IEnumerable<T> GetAll(Expression<Func<T, bool>>? predicate = null,string? includeproperties = null, string? stateproperties = null, string? cityproperties = null)
        {
            IQueryable<T> query = _dbSet;
            if(predicate!=null)
            {
                query = query.Where(predicate);
            }
            if(includeproperties != null && stateproperties!=null && cityproperties != null)
            {
                foreach (var item in includeproperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(item);
                }
                foreach (var item in stateproperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(item);
                }
                foreach (var item in cityproperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(item);
                }
            }
            return query.ToList();
        }

        public T GetT(Expression<Func<T, bool>> predicate, string? includeproperties = null)
        {
            IQueryable<T> query = _dbSet;
            query = query.Where(predicate);
            if (includeproperties != null)
            {
                foreach (var item in includeproperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(item);
                }
            }
            return query.FirstOrDefault();
        }
    }
}
