﻿using Assignment2.Data.IReposetory;
using Assignment2.Models;

namespace Assignment2.Data.Reposetory
{
    public class CityReposetory : reposetory<City>, ICityReposetory
    {
        private readonly NeoSoftVishalBoneContext _context;
        public CityReposetory(NeoSoftVishalBoneContext context) : base(context)
        {
            _context = context;
        }

        public void update(City city)
        {
            _context.Cities.Update(city);
        }
    }
}
