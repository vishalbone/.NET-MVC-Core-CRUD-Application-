﻿using Assignment2.Data.IReposetory;
using Assignment2.Models;

namespace Assignment2.Data.Reposetory
{
    public class StateReposetory : reposetory<State>, IStateReposetory
    {
        private readonly NeoSoftVishalBoneContext _context;
        public StateReposetory(NeoSoftVishalBoneContext context) : base(context)
        {
            _context = context;
        }

        public void update(State state)
        {
            _context.States.Update(state);
        }
    }
}
