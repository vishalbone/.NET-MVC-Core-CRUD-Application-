﻿using Assignment2.Data.IReposetory;
using Assignment2.Models;

namespace Assignment2.Data.Reposetory
{
    public class EmployeeReposetory : reposetory<EmployeeMaster>, IEmployeeReposetory
    {
        private readonly NeoSoftVishalBoneContext _context;
        public EmployeeReposetory(NeoSoftVishalBoneContext context) : base(context)
        {
            _context = context;
        }

        public void update(EmployeeMaster employee)
        {
            if(employee.PassPortNumber != null)
            {
                employee.PassPortNumber = employee.PassPortNumber.ToUpper();
            }
            if (employee.PanNumber != null)
            {
                employee.PanNumber = employee.PanNumber.ToUpper();
            }
            _context.EmployeeMasters.Update(employee);
        }
    }
}
