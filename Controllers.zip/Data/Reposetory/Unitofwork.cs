﻿using Assignment2.Data.IReposetory;

namespace Assignment2.Data.Reposetory
{
    public class Unitofwork : IUnitofwork
    {
        private readonly NeoSoftVishalBoneContext _dbcontext;

        public IEmployeeReposetory employei { get; private set; }

        public ICountryReposetory country { get; private set; }

        public IStateReposetory state { get; private set; }
        public ICityReposetory city { get; private set; }

        public Unitofwork(NeoSoftVishalBoneContext dbcontext) 
        {
            _dbcontext = dbcontext;
            employei = new EmployeeReposetory(dbcontext);
            country = new CountryReposetory(dbcontext);
            state = new StateReposetory(dbcontext);
            city = new CityReposetory(dbcontext);
        }
        public void save()
        {
            _dbcontext.SaveChanges();
        }
    }
}
//UQ__tmp_ms_x__D04F2C02ECB8C94D