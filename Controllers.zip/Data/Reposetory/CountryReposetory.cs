﻿using Assignment2.Data.IReposetory;
using Assignment2.Models;

namespace Assignment2.Data.Reposetory
{
    public class CountryReposetory : reposetory<Country>, ICountryReposetory
    {
        private readonly NeoSoftVishalBoneContext _context;
        public CountryReposetory(NeoSoftVishalBoneContext context) : base(context)
        {
            _context = context;
        }

        public void update(Country country)
        {
            _context.Countries.Update(country);
        }
    }
}
