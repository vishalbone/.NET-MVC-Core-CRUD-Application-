﻿using Assignment2.Models;

namespace Assignment2.Data.IReposetory
{
    public interface IStateReposetory : Ireposetory<State>
    {
        void update(State state);
    }
}
