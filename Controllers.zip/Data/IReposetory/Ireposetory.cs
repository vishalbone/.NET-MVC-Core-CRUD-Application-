﻿using Assignment2.Models;
using System.Linq.Expressions;

namespace Assignment2.Data.IReposetory
{
    public interface Ireposetory<T> where T : class
    {
        IEnumerable<T> GetAll(Expression<Func<T, bool>>? predicate=null,string? includeproperties = null, string? stateproperties = null, string? cityproperties = null);
        T GetT(Expression<Func<T, bool>> predicate, string? includeproperties = null);

        void Add(T item);

        void Delete(T item);
    }
}
