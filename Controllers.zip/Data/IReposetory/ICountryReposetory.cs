﻿using Assignment2.Models;

namespace Assignment2.Data.IReposetory
{
    public interface ICountryReposetory : Ireposetory<Country>
    {
        void update(Country country);
    }
}
