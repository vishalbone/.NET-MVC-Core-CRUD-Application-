﻿using Assignment2.Models;

namespace Assignment2.Data.IReposetory
{
    public interface ICityReposetory : Ireposetory<City>
    {
        void update(City city);
    }
}
