﻿namespace Assignment2.Data.IReposetory
{
    public interface IUnitofwork
    {
        IEmployeeReposetory employei { get; }
        ICountryReposetory country { get; }
        IStateReposetory state { get; }
        ICityReposetory city { get; }
        void save();
    }
}
