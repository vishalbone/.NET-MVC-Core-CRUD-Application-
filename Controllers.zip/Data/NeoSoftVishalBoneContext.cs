﻿using System;
using System.Collections.Generic;
using Assignment2.Models;
using Microsoft.EntityFrameworkCore;

namespace Assignment2.Data;

public partial class NeoSoftVishalBoneContext : DbContext
{
    public NeoSoftVishalBoneContext()
    {
    }

    public NeoSoftVishalBoneContext(DbContextOptions<NeoSoftVishalBoneContext> options)
        : base(options)
    {
    }

    public virtual DbSet<City> Cities { get; set; }

    public virtual DbSet<Country> Countries { get; set; }

    public virtual DbSet<EmployeeMaster> EmployeeMasters { get; set; }

    public virtual DbSet<State> States { get; set; }

    //    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
    //        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\ProjectModels;Initial Catalog=NeoSoft_VishalBone;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<City>(entity =>  
        {
            //entity.HasKey(e => e.CityId).HasName("PK__City__F2D21B7604AD1F76");
            entity.HasKey(e => e.CityId).HasName("PK__City__F2D21B76863F5779");

            entity.ToTable("City");

            entity.Property(e => e.CityId).ValueGeneratedNever();
            entity.Property(e => e.CityName)
                .HasMaxLength(50)
                .IsUnicode(false);

            //entity.HasOne(d => d.State).WithMany(p => p.Cities)
            //    .HasForeignKey(d => d.StateId)
            //    .HasConstraintName("FK__City__StateId__619B8048");
        });

        modelBuilder.Entity<Country>(entity =>
        {
            //entity.HasKey(e => e.CountryId).HasName("PK__tmp_ms_x__10D1609F2FDE1035");
            entity.HasKey(e => e.CountryId).HasName("PK__Country__10D1609F64B5D3CB");
           

            entity.ToTable("Country");

            entity.Property(e => e.CountryId).ValueGeneratedNever();
            entity.Property(e => e.CountryName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<EmployeeMaster>(entity =>
        {
            //entity.HasKey(e => e.RowId).HasName("PK__tmp_ms_x__7C36D07E2F1958E9");
            entity.HasKey(e => e.RowId).HasName("PK__Employee__7C36D07EC4A42690");

            entity.ToTable("EmployeeMaster");

            //entity.HasIndex(e => e.MobileNumber, "UQ__tmp_ms_x__250375B174D8478D").IsUnique();
            entity.HasIndex(e => e.MobileNumber, "UQ__Employee__250375B163F9A6DF").IsUnique();

            //entity.HasIndex(e => e.EmailAddress, "UQ__tmp_ms_x__49A1474006EE8169").IsUnique();
            entity.HasIndex(e => e.EmailAddress, "UQ__Employee__49A1474051439293").IsUnique();

            //entity.HasIndex(e => e.PanNumber, "UQ__tmp_ms_x__7C38BFC86AB506FE").IsUnique();
            entity.HasIndex(e => e.PanNumber, "UQ__Employee__7C38BFC8100DDB74").IsUnique();

            //entity.HasIndex(e => e.PassPortNumber, "UQ__tmp_ms_x__D04F2C028462CDE4").IsUnique();
            entity.HasIndex(e => e.PassPortNumber, "UQ__Employee__D04F2C028B425CA7").IsUnique();

            entity.Property(e => e.RowId).HasColumnName("Row_Id");
            //entity.Property(e => e.Cityname)
            //    .HasMaxLength(50)
            //    .IsUnicode(false)
            //    .HasColumnName("cityname");
            //entity.Property(e => e.CountryName)
            //    .HasMaxLength(50)
            //    .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.DateOfBirth).HasColumnType("date");
            entity.Property(e => e.DateofJoinee).HasColumnType("date");
            entity.Property(e => e.EmailAddress)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmployeeCode)
                .HasMaxLength(8)
                .IsUnicode(false)
                .HasComputedColumnSql("(right('00'+CONVERT([varchar](8),[Row_Id]),(8)))", true);
            entity.Property(e => e.Firstname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("FIRSTNAME");
            entity.Property(e => e.Lastname)
                .HasMaxLength(50)
                .HasColumnName("LASTNAME");
            entity.Property(e => e.MobileNumber)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.PanNumber)
                .HasMaxLength(12)
                .IsUnicode(false);
            entity.Property(e => e.PassPortNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            //entity.Property(e => e.Gender)
            //    .HasMaxLength(10);
            //entity.Property(e => e.IsActive)
            //    .HasMaxLength(10);
            entity.Property(e => e.ProfileImage).HasMaxLength(100);
            //entity.Property(e => e.StateName)
            //    .HasMaxLength(50)
            //    .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            //entity.HasOne(d => d.City).WithMany(p => p.EmployeeMasters)
            //    .HasForeignKey(d => d.CityId)
            //    .HasConstraintName("FK__EmployeeM__CityI__75A278F5");

            //entity.HasOne(d => d.Country).WithMany(p => p.EmployeeMasters)
            //    .HasForeignKey(d => d.CountryId)
            //    .HasConstraintName("FK__EmployeeM__Count__73BA3083");

            //entity.HasOne(d => d.State).WithMany(p => p.EmployeeMasters)
            //    .HasForeignKey(d => d.StateId)
            //    .HasConstraintName("FK__EmployeeM__State__74AE54BC");
        });

        modelBuilder.Entity<State>(entity =>
        {
            //entity.HasKey(e => e.StateId).HasName("PK__State__C3BA3B3ABE8ACAEF");
            entity.HasKey(e => e.StateId).HasName("PK__State__C3BA3B3A66ABB1F5");

            entity.ToTable("State");

            entity.Property(e => e.StateId).ValueGeneratedNever();
            entity.Property(e => e.StateName)
                .HasMaxLength(50)
                .IsUnicode(false);

            //entity.HasOne(d => d.Country).WithMany(p => p.States)
            //    .HasForeignKey(d => d.CountryId)
            //    .HasConstraintName("FK__State__CountryId__5EBF139D");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
