﻿var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
