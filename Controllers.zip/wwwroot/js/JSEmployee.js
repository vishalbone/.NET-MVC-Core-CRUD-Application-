﻿var dtable;
$(document).ready(function () {

    dtable = $('#myTable').DataTable({

        "ajax": {
            "url": "/Employee/Alldetails",

            "beforeSend": function () {
                // Show loader before AJAX request
                $(".loader-div").show();
            },
            "complete": function () {
                // Hide loader when AJAX request is complete
                setTimeout(function () {
                    $(".loader-div").hide();
                },1000);
                
            }
        },
        "columns": [
            { "data": 'emailAddress' },
            { "data": 'country.countryName' },
            { "data": 'state.stateName' },
            { "data": 'city.cityName' },
            { "data": 'panNumber' },
            { "data": 'passPortNumber' },
            { "data": 'gender' },
            { "data": 'isActive'},
            {
                "data": "profileImage",
                "render": function (data, type, row, meta) {
                    return '<img width="100px" height="100px" src="/Images/'+ data +'" />';
                    
                },
                "orderable": false
            },
            {
                "data": "rowId",
                "render": function (data) {
                    return `
                    <a href="/Employee/createupdate?id=${data}"><i class="bi bi-pencil-square"></i></a>
                    <a onClick=RemoveData("/Employee/delete/${data}")><i class="bi bi-trash3"></i></a>
                    
                    `
                },
                "orderable": false
            },
        ],
    });
});

//function check(elem) {
//    console.log(document.getElementById('mySelect1').value, "cont id");
//}

function RemoveData(url) {
    Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: url,
                type: 'DELETE',
                success: function (data) {
                    if (data.success) {
                        toastr.success(data.message);
                        dtable.ajax.reload();
                    }
                    else {
                        toastr.error(data.message);
                    }
                }
            })
        }
    });

    
}