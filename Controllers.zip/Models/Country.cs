﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Assignment2.Models;

public partial class Country
{
    public int CountryId { get; set; }

    [DisplayName("Country Name")]
    public string? CountryName { get; set; }

    //public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; } = new List<EmployeeMaster>();

    //public virtual ICollection<State> States { get; set; } = new List<State>();
}
