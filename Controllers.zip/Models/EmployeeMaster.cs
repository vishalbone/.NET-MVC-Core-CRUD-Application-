﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Assignment2.Models;

public partial class EmployeeMaster
{
    public int RowId { get; set; }
    [ValidateNever]
    public string EmployeeCode { get; set; } = null!;

    [DisplayName("First Name")]
    public string Firstname { get; set; } = null!;

    [DisplayName("Last Name")]
    public string? Lastname { get; set; }

    [DisplayName("Email Address")]
    public string EmailAddress { get; set; } = null!;

    [DisplayName("Mobile Number")]
    public string MobileNumber { get; set; } = null!;

    [DisplayName("PAN Number")]
    public string PanNumber { get; set; } = null!;

    [DisplayName("Passport Number")]
    public string PassPortNumber { get; set; } = null!;
    public string? ProfileImage { get; set; }

    public string? Gender { get; set; }

    public bool IsActive { get; set; }
    [ValidateNever]
    public DateOnly DateOfBirth { get; set; }
    [ValidateNever]
    public DateOnly? DateofJoinee { get; set; }
    [ValidateNever]
    public DateTime CreatedDate { get; set; } = DateTime.Now;

    public DateTime? UpdatedDate { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? DeletedDate { get; set; }

    public int? CountryId { get; set; }

    public int? StateId { get; set; }

    public int? CityId { get; set; }
    [ValidateNever]
    //public string CountryName { get; set; } = null!;
    //[ValidateNever]
    //public string StateName { get; set; } = null!;
    //[ValidateNever]
    //public string Cityname { get; set; } = null!;
    //[ValidateNever]
    public virtual City? City { get; set; }
    [ValidateNever]
    public virtual Country? Country { get; set; }
    [ValidateNever]
    public virtual State? State { get; set; }
}
