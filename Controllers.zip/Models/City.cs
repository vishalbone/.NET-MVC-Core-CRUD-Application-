﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Assignment2.Models;

public partial class City
{
    public int CityId { get; set; }

    [DisplayName("City Name")]
    public string? CityName { get; set; }

    public int? StateId { get; set; }

    //public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; } = new List<EmployeeMaster>();

    public virtual State? State { get; set; }
}
