﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Assignment2.Models.VM
{
    public class EmployeeVM
    {
        public EmployeeMaster employeemaster { get; set; } = new EmployeeMaster();

        public IEnumerable<EmployeeMaster> EmployeeMasters { get; set; } = new List<EmployeeMaster>();
        public IEnumerable<State> state { get; set; } = new List<State>();
        public IEnumerable<City> cite { get; set; } = new List<City>();
        [ValidateNever]
        public IEnumerable<SelectListItem> Countries { get; set; }
        [ValidateNever]

        public IEnumerable<SelectListItem> states { get; set; }
        [ValidateNever]

        public IEnumerable<SelectListItem> Cities { get; set; }
    }
}
