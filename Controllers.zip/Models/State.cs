﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Assignment2.Models;

public partial class State
{
    public int StateId { get; set; }

    public int? CountryId { get; set; }

    [DisplayName("State Name")]
    public string? StateName { get; set; }

    //public virtual ICollection<City> Cities { get; set; } = new List<City>();

    public virtual Country? Country { get; set; }

    //public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; } = new List<EmployeeMaster>();
}
